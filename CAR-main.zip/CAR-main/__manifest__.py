# -*- coding: utf-8 -*-
{
    'name': 'CAR',
    'summary': """This module will add a arachive to store CAR details""",
    'version': '10.0.1.0.0',
    'description': """This module will add a arachive to store CAR details""",
    'author': 'Hussien Alkhateeb',
    'company': 'Hussien Alkhateeb',
    'website': 'https://www.cybrosys.com',
    'category': 'Tools',
    'depends': ['base'],
    'license': 'AGPL-3',
    'data': [
        'views/view.xml',
    ],
    'demo': [],
    'installable': True,
    'auto_install': True,
}